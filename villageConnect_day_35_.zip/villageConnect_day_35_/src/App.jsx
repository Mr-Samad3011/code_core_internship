import { useEffect, useState } from "react";
import axiosInstance from "./api/axiosInstance";
import ServiceCard from "./components/ServiceCard";
import Spinner from "./components/Spinner";
import Navbar from "./components/Navbar";

export default function App() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axiosInstance.get("/services")
      .then((res) => {
        setServices(res.data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("API fetch failed:", err);
        setLoading(false);
      });
  }, []);

  return (
    <div className="min-h-screen w-screen flex flex-col bg-gray-100">
      {/* ✅ Full-width fixed navbar on top */}
      <Navbar />

      {/* ✅ Main content below navbar */}
      <main className="w-full max-w-6xl mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold text-blue-600 text-center mb-6">
          VillageConnect Services
        </h1>

        {loading ? (
          <Spinner />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s, i) => (
              <ServiceCard key={i} service={s} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
