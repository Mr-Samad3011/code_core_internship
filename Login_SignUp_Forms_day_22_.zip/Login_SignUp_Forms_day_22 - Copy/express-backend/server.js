const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const verifyToken = require('./middleware/authMiddleware');
const Service = require('./models/Service');

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect('mongodb+srv://abdussamad7562:DeEqkDob5KYLpe7t@cluster0.nl6kxfx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log("MongoDB connected"));

// Public Auth Routes
app.use('/api', authRoutes);

//  Protected Routes
app.get('/services', verifyToken, async (req, res) => {
  const services = await Service.find();
  res.json(services);
});

// const verifyToken = require('./middleware/authMiddleware');

app.get('/services', verifyToken, async (req, res) => {
  const services = await Service.find();
  res.json(services);
});

app.post('/services', verifyToken, async (req, res) => {
  const service = new Service(req.body);
  await service.save();
  res.status(201).json(service);
});

app.listen(3000, () => console.log("Server on http://localhost:3000"));
