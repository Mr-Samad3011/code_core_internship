import { useState } from "react";
import axios from "axios";

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      const res = await axios.post("http://localhost:3000/api/login", { email, password });
      localStorage.setItem("token", res.data.token);
      alert("Login successful");
      window.location.href = "/";
     // or navigate to dashboard
    } catch (err) {
      alert(err.response?.data?.error || "Login failed");
    }
  };

  return (
    <div className="p-6 max-w-sm mx-auto">
      <input className="w-full p-2 mb-2 border" type="email" onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
      <input className="w-full p-2 mb-2 border" type="password" onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
      <button className="w-full bg-blue-600 text-white py-2" onClick={handleLogin}>Login</button>
    </div>
  );
};

export default Login;
