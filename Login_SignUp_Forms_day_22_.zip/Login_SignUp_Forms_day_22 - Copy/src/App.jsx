import { useEffect, useState } from "react";
import axiosInstance from "./api/axiosInstance";
import SearchBar from "./components/SearchBar";
import { useNavigate } from "react-router-dom";

export default function App() {
  const [services, setServices] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");

    if (!token) {
      alert("Please login first");
      navigate("/login");
      return;
    }

    axiosInstance.get("/services")
      .then((res) => setServices(res.data))
      .catch((err) => {
        console.error("API Error:", err);
        alert("Unauthorized or expired token");
        localStorage.removeItem("token");
        navigate("/login");
      });
  }, []);

  const filtered = services.filter(service =>
    service?.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    service?.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Protected Services Dashboard</h1>
      <SearchBar searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map(service => (
          <div key={service._id} className="bg-white shadow p-4 rounded">
            <h2 className="font-semibold">{service.name}</h2>
            <p>{service.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
