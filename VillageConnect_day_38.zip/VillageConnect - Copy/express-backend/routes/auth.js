const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const User = require("../models/user");

    const token = "testtoken123"; // Replace with JWT token if needed
    
// POST /api/register
router.post("/register", async (req, res) => {
  try {
    const {
      name, email, phone, userId, dob,
      qualification, address, password,
    } = req.body;

    // Basic validation
    if (
      !name || !email || !phone || !userId || !dob ||
      !qualification || !address || !password
    ) {
      return res.status(400).json({ error: "Please fill all fields" });
    }

    // Check if user already exists
    const existing = await User.findOne({
      $or: [{ email }, { phone }, { userId }]
    });
    if (existing) {
      return res.status(400).json({ error: "User already exists" });
    }

    const newUser = new User({
      name, email, phone, userId, dob,
      qualification, address, password
    });

    await newUser.save();
    res.status(201).json({ message: "User registered successfully!" });
  } catch (err) {
    console.error("Registration error:", err);
    res.status(500).json({ error: "Server error" });
  }
});


router.post("/login", async (req, res) => {
  const { identifier, password } = req.body;

  if (!identifier || !password) {
    return res.status(400).json({ error: "Please fill all fields" });
  }

  try {
    // Find user using email, phone, or userId
    const user = await User.findOne({
      $or: [
        { email: identifier },
        { phone: identifier },
        { userId: identifier }
      ]
    });

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    // Compare hashed password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: "Invalid password" });
    }



    res.json({
      token,
      user: {
        name: user.name,
        email: user.email,
        phone: user.phone,
        userId: user.userId,
      },
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Server error" });
  }
});


// Forget Password Endpoint
router.post("/verify-user", async (req, res) => {
  const { email, dob } = req.body;

  try {
    const user = await User.findOne({ email, dob });
    if (!user) {
      return res.status(400).json({ error: "Invalid email or DOB" });
    }
    return res.json({ message: "User verified", userId: user._id });
  } catch (err) {
    return res.status(500).json({ error: "Server error" });
  }
});

router.post("/reset-password", async (req, res) => {
  const { userId, newPassword } = req.body;

  try {
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    //  Hash the new password before saving
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(newPassword, salt);
    user.password = hashedPassword;

    await user.save();

    return res.json({ message: "Password reset successfully" });
  } catch (err) {
    console.error("Password reset error:", err);
    return res.status(500).json({ error: "Server error" });
  }
});





module.exports = router;
