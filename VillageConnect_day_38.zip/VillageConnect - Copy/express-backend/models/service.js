// models/service.js
const mongoose = require("mongoose");

const serviceSchema = new mongoose.Schema({
  name: String,
  category: String,
  address:String,
  availability:String,
  contact: String,
  description: String,
  information: String,
  servicename:String,
   createdBy: String,
  date: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Service", serviceSchema);
