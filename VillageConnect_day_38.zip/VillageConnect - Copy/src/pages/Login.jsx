import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import axios from "axios";

export default function Login({ setLoggedIn, setUser }) {
  const [form, setForm] = useState({ identifier: "", password: "" });
  const [message, setMessage] = useState(""); //  Message text
  const [messageType, setMessageType] = useState("success"); // success / error / warning
  const navigate = useNavigate();
  const location = useLocation();

  const showAuthWarning = new URLSearchParams(location.search).get("auth");

  // Show unauthorized access warning if redirected
  useState(() => {
    if (showAuthWarning) {
      setMessage("You must be logged in to access that page.");
      setMessageType("warning");
    }
  }, [showAuthWarning]);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/auth/login", form);
      const { token, user } = res.data;

      localStorage.setItem("token", token);
      localStorage.setItem("user", JSON.stringify(user));
      setLoggedIn(true);
      setUser(user);

      setMessage("Login successful! Redirecting...");
      setMessageType("success");

      setTimeout(() => {
        setMessage(""); // Hide message
        navigate("/"); // Redirect after delay
      }, 1500);
    // eslint-disable-next-line no-unused-vars
    } catch (err) {
      setMessage("Login failed. Please check your credentials.");
      setMessageType("error");
    }
  };

  // Message style based on type
  const getMessageStyle = () => {
    switch (messageType) {
      case "success":
        return "bg-green-100 border-green-400 text-green-700";
      case "error":
        return "bg-red-100 border-red-400 text-red-700";
      case "warning":
        return "bg-yellow-100 border-yellow-400 text-yellow-800";
      default:
        return "";
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-100 to-blue-200 p-4">
      {message && (
        <div
          className={`absolute top-8 border px-4 py-2 rounded shadow ${getMessageStyle()}`}
        >
          {message}
        </div>
      )}

      <form
        onSubmit={handleLogin}
        className="w-full max-w-sm bg-white shadow-lg rounded-xl p-8 space-y-6"
      >
        <h2 className="text-2xl font-bold text-center text-blue-700">Login</h2>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Username / Email / Phone
          </label>
          <input
            type="text"
            placeholder="Enter identifier"
            className="mt-1 w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            onChange={(e) => setForm({ ...form, identifier: e.target.value })}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Password</label>
          <input
            type="password"
            placeholder="Enter password"
            className="mt-1 w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition"
        >
          Login
        </button>

        <div className="flex justify-between items-center text-sm text-gray-600">
          <Link to="/forgot-password" className="text-blue-500 hover:underline">
            Forgot Password?
          </Link>
          <Link to="/signup" className="hover:underline text-blue-600">
            Signup
          </Link>
        </div>
      </form>
    </div>
  );
}
