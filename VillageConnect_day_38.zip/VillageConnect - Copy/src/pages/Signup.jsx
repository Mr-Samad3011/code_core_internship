import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Signup() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    userId: "",
    dob: "",
    qualification: "",
    address: "",
    password: "",
    confirmPassword: "",
  });

  const [modal, setModal] = useState({ show: false, message: "", type: "info" });
  const navigate = useNavigate();

  const showModalMessage = (message, type = "info", redirect = false) => {
    setModal({ show: true, message, type });
    setTimeout(() => {
      setModal({ show: false, message: "", type: "info" });
      if (redirect) navigate("/login");
    }, 3000);
  };

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleNext = () => {
    if (
      !formData.name ||
      !formData.email ||
      !formData.phone ||
      !formData.userId ||
      !formData.dob
    ) {
      showModalMessage("Please fill all Step 1 fields", "warning");
      return;
    }
    setStep(2);
  };

  const handleBack = () => setStep(1);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      showModalMessage("Passwords do not match!", "error");
      return;
    }

    try {
      const response = await fetch("http://localhost:5000/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        showModalMessage("Registration successful! Redirecting...", "success", true);
      } else {
        showModalMessage(data.error || "Something went wrong", "error");
      }
    } catch (err) {
      console.error("Signup error:", err);
      showModalMessage("Server error", "error");
    }
  };

  const getModalStyle = () => {
    switch (modal.type) {
      case "success":
        return "bg-green-100 border-green-400 text-green-800";
      case "error":
        return "bg-red-100 border-red-400 text-red-700";
      case "warning":
        return "bg-yellow-100 border-yellow-400 text-yellow-800";
      default:
        return "bg-blue-100 border-blue-400 text-blue-700";
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4">
      <div className="bg-white shadow-md rounded-lg p-8 w-full max-w-2xl relative">
        <h2 className="text-2xl font-bold mb-6 text-center text-blue-600">
          Signup - Step {step}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          {step === 1 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {["name", "email", "phone", "userId", "dob"].map((field) => (
                <div key={field}>
                  <label className="block font-semibold mb-1 text-orange-500 capitalize">
                    {field === "dob" ? "Date of Birth" : field}
                  </label>
                  <input
                    type={field === "email" ? "email" : field === "dob" ? "date" : "text"}
                    name={field}
                    value={formData[field]}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded px-3 py-2"
                    required
                  />
                </div>
              ))}
            </div>
          )}

          {step === 2 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {["qualification", "address", "password", "confirmPassword"].map((field) => (
                <div key={field}>
                  <label className="block font-semibold mb-1 text-orange-500 capitalize">
                    {field === "confirmPassword" ? "Confirm Password" : field}
                  </label>
                  <input
                    type={(field === "password" || field === "confirmPassword") ? "password" : "text"}
                    name={field}
                    value={formData[field]}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded px-3 py-2"
                    required
                  />
                </div>
              ))}
            </div>
          )}

          <div className="flex justify-between mt-6">
            {step === 2 && (
              <button
                type="button"
                onClick={handleBack}
                className="bg-gray-300 hover:bg-gray-400 text-gray-700 font-semibold py-2 px-4 rounded"
              >
                Back
              </button>
            )}
            {step === 1 && (
              <button
                type="button"
                onClick={handleNext}
                className="ml-auto bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded"
              >
                Next
              </button>
            )}
            {step === 2 && (
              <button
                type="submit"
                className="ml-auto bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded"
              >
                Signup
              </button>
            )}
          </div>
        </form>

        {/* 🔔 Modal for all messages */}
        {modal.show && (
          <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center z-10">
            <div className={`rounded-lg border px-6 py-4 shadow-md ${getModalStyle()}`}>
              <p className="font-semibold">{modal.message}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
