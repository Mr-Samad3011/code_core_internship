import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const ServiceForm = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    category: '',
    name: '',
    contact: '',
    address: '',
    description: '',
    information: '',
    availability: '',
    servicename: '',
  });

  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const user = JSON.parse(localStorage.getItem("user"));
  const userEmail = user?.email;

  useEffect(() => {
    if (!userEmail) {
      navigate("/login?auth=true");
    }
  }, [userEmail, navigate]);

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      // eslint-disable-next-line no-unused-vars
      const response = await axios.post("http://localhost:5000/api/services", {
        ...formData,
        date: new Date().toISOString(),
        createdBy: userEmail,
      });

      setMessage("✅ Service added successfully!");
      setFormData({
        category: '',
        name: '',
        contact: '',
        address: '',
        description: '',
        information: '',
        availability: '',
        servicename: '',
      });
    } catch (error) {
      console.error(error);
      setMessage("❌ Failed to add service. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-blue-50 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-white p-6 rounded-xl shadow-xl">
        <h2 className="text-2xl font-bold mb-4 text-blue-700">Add a New Service</h2>

        {message && (
          <p className="mb-4 text-center text-sm font-medium text-green-600">{message}</p>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Fields with placeholders */}
          {[
            {
              label: "Service Name",
              name: "servicename",
              type: "text",
              placeholder: "e.g. Local Electrician, Organic Farmer",
            },
            {
              label: "Category",
              name: "category",
              type: "text",
              placeholder: "e.g. Repair, Farming, Education",
            },
            {
              label: "Name",
              name: "name",
              type: "text",
              placeholder: "e.g. Ramesh Kumar",
            },
            {
              label: "Contact",
              name: "contact",
              type: "text",
              placeholder: "e.g. +91 9876543210",
            },
            {
              label: "Address",
              name: "address",
              type: "text",
              placeholder: "e.g. Village Rampur, Block A, District Bijnor",
            },
          ].map(({ label, name, type, placeholder }) => (
            <div key={name}>
              <label className="block mb-1 text-gray-700 font-semibold">{label}</label>
              <input
                type={type}
                name={name}
                value={formData[name]}
                onChange={handleChange}
                required
                placeholder={placeholder}
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-300"
              />
            </div>
          ))}

          {/* Textareas with placeholders */}
          {[
            {
              label: "Description",
              name: "description",
              rows: 3,
              placeholder: "e.g. Providing affordable electrical repairs and installations.",
            },
            {
              label: "Information",
              name: "information",
              rows: 4,
              placeholder: "e.g. Charges depend on work type. Emergency service available.",
            },
            {
              label: "Availability",
              name: "availability",
              rows: 4,
              placeholder: "e.g. Mon-Sat, 10:00 AM to 6:00 PM",
            },
          ].map(({ label, name, rows, placeholder }) => (
            <div key={name}>
              <label className="block mb-1 text-gray-700 font-semibold">{label}</label>
              <textarea
                name={name}
                value={formData[name]}
                onChange={handleChange}
                required
                rows={rows}
                placeholder={placeholder}
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-300"
              ></textarea>
            </div>
          ))}

          <button
            type="submit"
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md w-full font-semibold transition"
          >
            {loading ? "Submitting..." : "Submit Service"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ServiceForm;
