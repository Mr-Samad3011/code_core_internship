import { FaGithub, FaLinkedin, FaInstagram, FaWhatsapp } from "react-icons/fa";
import { MdEmail, MdPhone } from "react-icons/md";

export default function About() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 to-blue-100 text-gray-800">
      <div className="max-w-4xl mx-auto px-4 py-16">
        <h1 className="text-4xl font-bold text-center text-blue-700 mb-6">About Me</h1>

        <div className="bg-white rounded-xl shadow-md p-6 space-y-6">
          <p className="text-lg text-gray-700">
            Hi, I'm <span className="font-semibold text-blue-600">Abdus Samad</span>, a passionate Full Stack Developer.
            I enjoy building modern, responsive web applications with a focus on clean UI, backend integration, and user experience.
          </p>

          <div className="grid sm:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h2 className="text-xl font-semibold text-blue-600">Contact Info</h2>
              <p className="flex items-center gap-2"><MdEmail className="text-blue-500" /><a href="mailto:abdussamad.7562@gmail.com">abdussamad.7562@gmail.com</a></p>
              <p className="flex items-center gap-2"><MdPhone className="text-blue-500" /> <a href="tel:+91-9519770595">+91-9519770595</a></p>
              <p className="flex items-center gap-2"><FaWhatsapp className="text-green-500" /> <a href="https://wa.me/+919519770595" className="text-blue-600 hover:underline" target="_blank">Message on WhatsApp</a></p>
            </div>

            <div className="space-y-3">
              <h2 className="text-xl font-semibold text-blue-600">Social Links</h2>
              <p className="flex items-center gap-2"><FaGithub className="text-black" /> <a href="https://github.com/Mr-Samad3011" className="text-blue-600 hover:underline" target="_blank">GitHub</a></p>
              <p className="flex items-center gap-2"><FaLinkedin className="text-blue-700" /> <a href="https://www.linkedin.com/in/abdus-samad-7a6864304" className="text-blue-600 hover:underline" target="_blank">LinkedIn</a></p>
              <p className="flex items-center gap-2"><FaInstagram className="text-pink-500" /> <a href="https://www.instagram.com/mr__samad1130/" className="text-blue-600 hover:underline" target="_blank">Instagram</a></p>
            </div>
          </div>
        </div>
      </div>

      <footer className="bg-blue-600 text-white text-center py-4 mt-auto">
        © {new Date().getFullYear()} Abdus Samad. All rights reserved.
      </footer>
    </div>
  );
}
