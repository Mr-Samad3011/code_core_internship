import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Menu, X ,Search, User } from 'lucide-react';


export default function Navbar({ loggedIn, setLoggedIn, user }) {
  const [username, setUsername] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      setUsername(user.name || user.userId || "User");
    } else {
      setUsername("");
    }
  }, [user, loggedIn]);

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setLoggedIn(false);
    setUsername("");
    navigate("/login");
    setMenuOpen(false);
  };

  const toggleMenu = () => setMenuOpen(!menuOpen);

  return (
    <nav className="bg-blue-600 text-white px-4 py-3 shadow-md">
      <div className="max-w-6xl mx-auto flex justify-between items-center">
        <div className="text-xl font-bold">VillageConnect</div>

        {/* Hamburger Icon */}
        <div className="md:hidden">
          <button onClick={toggleMenu}>
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Desktop Menu */}
        <ul className="hidden md:flex space-x-6 items-center">
          <li><Link to="/" className="hover:underline">Home</Link></li>
          <li>
            {loggedIn ? (
              <Link to="/add-service" className="hover:underline">Services</Link>
            ) : (
              <span className="text-gray-300 cursor-not-allowed">Services</span>
            )}
          </li>
          <li><Link to="/forum" className="hover:underline">Forum</Link></li>

          {!loggedIn ? (
            <>
              <li><Link to="/signup" className="hover:underline">Signup</Link></li>
              <li><Link to="/login" className="hover:underline">Login</Link></li>
            </>
          ) : (
            <>
              <li className="text-sm text-yellow-200">Welcome, {username}</li>
              <li>
                <button
                  onClick={logout}
                  className="hover:underline text-red-200"
                >
                  Logout
                </button>
              </li>
            </>
          )}
        </ul>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <ul className="md:hidden mt-4 space-y-3 px-4">
          <li><Link to="/" className="block hover:underline" onClick={toggleMenu}>Home</Link></li>
          <li>
            {loggedIn ? (
              <Link to="/add-service" className="block hover:underline" onClick={toggleMenu}>Services</Link>
            ) : (
              <span className="block text-gray-300 cursor-not-allowed">Services</span>
            )}
          </li>
          <li><Link to="/forum" className="block hover:underline" onClick={toggleMenu}>Forum</Link></li>

          {!loggedIn ? (
            <>
              <li><Link to="/signup" className="block hover:underline" onClick={toggleMenu}>Signup</Link></li>
              <li><Link to="/login" className="block hover:underline" onClick={toggleMenu}>Login</Link></li>
            </>
          ) : (
            <>
              <li className="text-sm text-yellow-200">Welcome, {username}</li>
              <li>
                <button
                  onClick={logout}
                  className="hover:underline text-red-200"
                >
                  Logout
                </button>
              </li>
            </>
          )}
        </ul>
      )}
    </nav>
  );
}
