const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();
const app = express();
app.use(cors({
  origin: "http://localhost:5173", 
  methods: ["GET", "POST", "PUT", "DELETE"],
  allowedHeaders: ["Content-Type"],
}));
app.use(express.json());
//Route import
const Service = require("./models/service");
const serviceRoutes = require("./routes/serviceRoutes");
const postRoutes = require("./routes/forumRoutes");
app.use("/api/posts", postRoutes);




app.use("/api/services", serviceRoutes);
app.use("/api/posts", postRoutes);
// Connect to MongoDB
mongoose.connect("Enter here path db connection")
  .then(() => console.log("MongoDB connected to villageconnect"))
  .catch((err) => console.error("MongoDB error:", err));

// Default Routes
app.get("/api/services", async (req, res) => {
  try {
    const services = await Service.find();
    res.json(services);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch services" });
  }
});

app.post("/api/services", async (req, res) => {
  try {
    const { name, category, description } = req.body;
    const newService = new Service({ name, category, description });
    await newService.save();
    res.status(201).json(newService);
  } catch (err) {
    console.error("Error in POST /api/services", err); // 
    res.status(400).json({ error: "Failed to create service" });
  }
});

app.get("/api/seed", async (req, res) => {
  const data = [
    {
      name: "Soil Testing",
      category: "Agriculture",
      description: "Helps farmers improve crop yield by testing soil quality."
    },
    {
      name: "Telemedicine",
      category: "Health",
      description: "Remote access to doctors for villagers."
    }
  ];

  try {
    await Service.insertMany(data);
    res.send("Sample services inserted into villageconnect DB.");
  } catch (err) {
    console.error("Error inserting seed data:", err);
    res.status(500).send("Failed to insert services.");
  }
});

app.get("/api/clear", async (req, res) => {
  await Service.deleteMany({});
  res.send(" All services deleted");
});

// Start the server
app.listen(5000, () => {
  console.log("Server running at http://localhost:5000");
});
