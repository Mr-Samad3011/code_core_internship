import { useEffect, useState } from "react";
import axios from "../api/axiosInstance";
import ServiceCard from "../components/ServiceCard";

export default function Home() {
  const [services, setServices] = useState([]);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const res = await axios.get("/services");
        setServices(res.data);
      } catch (err) {
        console.error("Error fetching services", err);
      }
    };

    fetchServices();
  }, []);

  return (
    <div className="min-h-screen w-screen bg-gray-100 flex flex-col">
      <h1 className="text-2xl font-bold text-center mb-6 text-blue-500">
        VillageConnect Services
      </h1>

      <div className="flex-grow grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-6xl mx-auto">
        {services.map((service, i) => (
          <ServiceCard key={i} service={service} />
        ))}
      </div>
    </div>
  );
}
