import { useEffect, useState } from "react";
import ServiceCard from "./components/ServiceCard";
import axiosInstance from "./api/axiosInstance";
import Navbar from "./components/Navbar";

export default function App() {
  const [services, setServices] = useState([]);

  useEffect(() => {
    axiosInstance.get("/services")
      .then((res) => setServices(res.data))
      .catch((err) => console.error("API Error:", err));
  }, []);

  return (
    <div className="min-h-screen w-screen flex flex-col bg-gray-100">
      <Navbar />

      <main className="flex-grow w-full max-w-6xl mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold text-center text-blue-600 mb-6">
          VillageConnect Services
        </h1>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, i) => (
            <ServiceCard key={i} service={s} />
          ))}
        </div>
      </main>
    </div>
  );
}
