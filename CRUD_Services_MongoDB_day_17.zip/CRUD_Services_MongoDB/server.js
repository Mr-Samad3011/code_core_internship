const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();
const Service = require('./models/service');

app.use(express.json());
app.use(cors());

// Replace with your own connection string
mongoose.connect('mongodb+srv://abdussamad7562:DeEqkDob5KYLpe7t@cluster0.nl6kxfx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch((err) => console.log('MongoDB connection error:', err));

// Server
app.listen(3000, () => console.log('Server running on port 3000'));



// CREATE
app.post('/services', async (req, res) => {
  try {
    const service = new Service(req.body);
    await service.save();
    res.status(201).json(service);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// READ ALL
app.get('/services', async (req, res) => {
  const services = await Service.find();
  res.json(services);
});

// READ ONE
app.get('/services/:id', async (req, res) => {
  const service = await Service.findById(req.params.id);
  if (!service) return res.status(404).json({ error: 'Not found' });
  res.json(service);
});

// UPDATE
app.put('/services/:id', async (req, res) => {
  try {
    const service = await Service.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(service);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE
app.delete('/services/:id', async (req, res) => {
  try {
    await Service.findByIdAndDelete(req.params.id);
    res.json({ message: 'Service deleted' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
