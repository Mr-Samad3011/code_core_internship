export default function ServiceCard({ service }) {
  return (
    <div className="bg-white p-4 rounded shadow">
      <h2 className="text-xl font-bold mb-2 text-gray-400">{service.name}</h2>
      <p className="text-gray-600 mb-1">Category: {service.category}</p>
      <p className="text-gray-800">{service.description}</p>
    </div>
  );
}
