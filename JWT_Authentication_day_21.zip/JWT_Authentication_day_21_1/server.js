const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/Auth');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb+srv://abdussamad7562:DeEqkDob5KYLpe7t@cluster0.nl6kxfx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log(' MongoDB Connected'))
  .catch(err => console.error(err));

app.use('/api', authRoutes);

app.listen(5000, () => console.log(' Server running on http://localhost:5000'));
