import ProductCard from "./components/ProductCard";

const sampleProduct = {
  name: "Wireless Headphones",
  price: 2499,
  image: "https://m.media-amazon.com/images/I/517lSvEVVsL._SX679_.jpg",
  
};

export default function App() {
  return (
   <div className="h-screen w-screen flex items-center justify-center bg-gray-100 p-6">
  <div className="text-center text-orange-500">
    <h1 className="text-2xl font-bold mb-6">Day 26: Product Card Test</h1>
    <div className="max-w-md mx-auto">
      <ProductCard product={sampleProduct} />
    </div>
  </div>
</div>

  );
}
