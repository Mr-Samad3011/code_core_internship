import Navbar from './navbar';
import { useState, useEffect } from 'react';
import axios from 'axios';

function Api_Hooks() {
  const [tasks, setTasks] = useState([]);
  const [input, setInput] = useState('');

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    const res = await axios.get('http://localhost:3000/api/tasks');
    setTasks(res.data);
  };

  const addTask = async () => {
    if (input.trim()) {
      await axios.post('http://localhost:3000/api/tasks', { task: input });
      setInput('');
      fetchTasks();
    }
  };

  const deleteTask = async (index) => {
    await axios.delete(`http://localhost:3000/api/tasks/${index}`);
    fetchTasks();
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Navbar />

      <div className="flex-1 flex flex-col items-center justify-start p-4">
        <div className="w-full max-w-md bg-white p-6 rounded-xl shadow-lg">
          <div className="flex mb-4">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Enter a task..."
              className="flex-1 border px-4 py-2 rounded-l-md focus:outline-none"
            />
            <button
              onClick={addTask}
              className="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600"
            >
              Add
            </button>
          </div>

          <ul className="space-y-2">
            {tasks.map((task, index) => (
              <li
                key={index}
                className="flex justify-between items-center bg-gray-50 px-4 py-2 rounded border text-blue-500"
              >
                <span>{task}</span>
                <button
                  onClick={() => deleteTask(index)}
                  className="text-red-500 hover:text-red-700"
                >
                  Delete
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Api_Hooks;
