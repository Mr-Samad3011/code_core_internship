import { useState, useEffect, useRef } from "react";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const menuWrapRef = useRef(null);

  useEffect(() => {
    function handlePointerDown(e) {
      if (open && menuWrapRef.current && !menuWrapRef.current.contains(e.target)) {
        setOpen(false);
      }
    }
    document.addEventListener("pointerdown", handlePointerDown);
    return () => document.removeEventListener("pointerdown", handlePointerDown);
  }, [open]);

  return (
    <nav className="w-full bg-blue-600 text-white px-4 py-3 shadow-md">
      <div className="max-w-7xl mx-auto">
     
        <div className="flex items-center justify-between flex-nowrap gap-2">
          <h1 className="text-xl font-bold whitespace-nowrap">📝 To-Do App</h1>

          <div className="hidden md:flex gap-4">
            <a href="#" className="hover:underline">Home</a>
            <a href="#" className="hover:underline">About</a>
          </div>

        
          <div className="md:hidden relative" ref={menuWrapRef}>
            <button
              type="button"
              aria-label="Toggle menu"
              aria-expanded={open}
              aria-controls="mobile-menu"
              onClick={() => setOpen(v => !v)}
              className="p-2 rounded focus:outline-none focus:ring-2 focus:ring-white/60"
            >
              {open ? (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              )}
            </button>

     
            <div
              id="mobile-menu"
              className={`absolute right-0 top-full mt-2 w-40 rounded-lg bg-blue-700 shadow-lg overflow-hidden transition-[max-height,opacity] duration-200 ${
                open ? "max-h-48 opacity-100" : "max-h-0 opacity-0 pointer-events-none"
              }`}
            >
              <div className="flex flex-col">
                <a href="#" className="px-4 py-2 hover:bg-blue-600">Home</a>
                <a href="#" className="px-4 py-2 hover:bg-blue-600">About</a>
              </div>
            </div>
          </div>
        </div>
    
      </div>
    </nav>
  );
}
