import { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

export default function App() {
  const [services, setServices] = useState([]);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      setIsAuthenticated(false);
      return;
    }

    axios.get("http://localhost:5000/services", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => {
        setServices(res.data);
        setIsAuthenticated(true);
      })
      .catch(() => {
        alert("Unauthorized access");
        localStorage.removeItem("token");
        navigate("/login");
      });
  }, []);

  // If not logged in, show Login + Signup
  if (!isAuthenticated) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-gray-100">
        <h1 className="text-3xl font-bold mb-6">Welcome to the App</h1>
        <div className="flex space-x-4">
          <Link to="/login" className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            Login
          </Link>
          <Link to="/signup" className="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700">
            Signup
          </Link>
        </div>
      </div>
    );
  }

  // If authenticated, show dashboard
  return (
    <div className="h-screen w-screen flex flex-col items-center justify-center bg-gray-100">
      <button
        onClick={() => {
          localStorage.removeItem("token");
          navigate("/login");
        }}
        className="absolute top-4 right-4 bg-red-500 text-white px-4 py-1 rounded"
      >
        Logout
      </button>
      <h1 className="text-2xl font-bold mb-4">Dashboard (Protected)</h1>
      <ul className="bg-white p-4 rounded shadow w-full max-w-md">
        {services.map((s) => (
          <li key={s._id} className="border-b py-2">{s.name}</li>
        ))}
      </ul>
    </div>
  );
}
