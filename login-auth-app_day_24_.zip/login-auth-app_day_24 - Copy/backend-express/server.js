const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const verifyToken = require('./middleware/authMiddleware');
const Service = require('./models/Service');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb+srv://abdussamad7562:DeEqkDob5KYLpe7t@cluster0.nl6kxfx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log(' MongoDB connected'))
  .catch((err) => console.error(' MongoDB connection error:', err));

app.use('/api', authRoutes);

//  Protected route
app.get('/services', verifyToken, async (req, res) => {
  const services = await Service.find();
  res.json(services);
});

app.listen(5000, () => console.log('🚀 Server running on http://localhost:5000'));