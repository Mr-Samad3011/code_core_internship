import { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from './navbar';
// import Index from '../server/Index.JS'
function Api_Hooks() {
  const [tasks, setTasks] = useState([]);
  const [input, setInput] = useState('');

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    const res = await axios.get('http://localhost:3000/api/tasks');
    setTasks(res.data);
  };

  const addTask = async () => {
    if (input.trim()) {
      await axios.post('http://localhost:3000/api/tasks', { task: input });
      setInput('');
      fetchTasks();
    }
  };

  const deleteTask = async (index) => {
    await axios.delete(`http://localhost:3000/api/tasks/${index}`);
    fetchTasks();
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />

      <div className="flex flex-col items-center mt-10 px-4">
        <div className="w-full max-w-md bg-white p-6 rounded-lg shadow-md">
          <div className="flex mb-4">
            <input
              type="text"
              className="flex-1 px-4 py-2 border rounded-l-md focus:outline-none"
              placeholder="Enter a task..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
            <button
              onClick={addTask}
              className="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600"
            >
              Add
            </button>
          </div>

          <ul className="space-y-2">
            {tasks.map((task, index) => (
              <li
                key={index}
                className="flex justify-between items-center bg-gray-50 px-4 py-2 rounded-md border  text-black"
              >
                <span>{task}</span>
                <button
                  onClick={() => deleteTask(index)}
                  className="text-red-500 hover:text-red-700"
                >
                  Delete
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Api_Hooks;
