const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

let tasks = [];

app.get('/api/tasks', (req, res) => res.json(tasks));

app.post('/api/tasks', (req, res) => {
  const { task } = req.body;
  if (task) {
    tasks.push(task);
    res.status(201).json({ message: 'Task added' });
  } else {
    res.status(400).json({ error: 'Task is required' });
  }
});

app.delete('/api/tasks/:index', (req, res) => {
  const index = parseInt(req.params.index);
  if (!isNaN(index) && tasks[index]) {
    tasks.splice(index, 1);
    res.json({ message: 'Task deleted' });
  } else {
    res.status(404).json({ error: 'Invalid task index' });
  }
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
