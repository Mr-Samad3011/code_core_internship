export default function ServiceCard({ service }) {
  return (
    <div className="bg-white shadow-md p-4 rounded">
      <h2 className="text-lg font-semibold text-gray-800">{service.name}</h2>
      <p className="text-sm text-gray-600">Category: {service.category}</p>
      <p className="text-sm text-gray-600">Name: {service.name}</p>
      <p className="text-sm text-gray-600">Contact: {service.contact}</p>
      <p className="text-sm text-gray-600">Address: {service.address}</p>
      <p className="text-sm text-gray-700">Description: {service.description}</p>
      <p className="text-sm text-gray-600">Information: {service.information}</p>
      <p className="text-sm text-gray-600">Availability: {service.availability}</p>
    </div>
  );
}
