import { BrowserRouter, Routes, Route } from "react-router-dom";
import Forum from "./pages/Forum";
import Navbar from "./components/Navbar";
import ServiceCard from "./components/ServiceCard";
import Spinner from "./components/Spinner";
import axiosInstance from "./api/axiosInstance";
import { useEffect, useState } from "react";
import Signup from "./pages/Signup";
import Login from "./pages/Login";
import About from "./pages/About";
import ServiceForm from "./pages/ServiceForm";
import ForgotPassword from "./pages/ForgotPassword"; 
import PrivateRoute from "./components/privateRoute";

export default function App() {
  const [loggedIn, setLoggedIn] = useState(() => {
    return localStorage.getItem("token") !== null;
  });
  const [user, setUser] = useState(() => {
    const userData = localStorage.getItem("user");
    return userData ? JSON.parse(userData) : null;
  });
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axiosInstance.get("/services")
      .then(res => {
        setServices(res.data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  return (
    <BrowserRouter>
      <div className="min-h-screen w-screen flex flex-col bg-gray-100">
        <Navbar loggedIn={loggedIn} setLoggedIn={setLoggedIn} user={user} />
        <Routes>
          <Route path="/" element={
            <main className="w-full max-w-6xl mx-auto px-4 py-6">
              <h1 className="text-2xl font-bold text-blue-600 text-center mb-6">
                VillageConnect Services
              </h1>
              {loading ? (
                <Spinner />
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {services.map((s, i) => (
                    <ServiceCard key={i} service={s} />
                  ))}
                </div>
              )}
            </main>
          } />
         <Route path="/forum" element={ <PrivateRoute loggedIn={loggedIn}> <Forum user={user} /> </PrivateRoute>   } />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login setLoggedIn={setLoggedIn} setUser={setUser} />} />
          <Route path="/about" element={<About />} />
          <Route path="/add-service"  element={ <PrivateRoute loggedIn={loggedIn}> <ServiceForm user={user} />  </PrivateRoute>  } />
           <Route path="/forgot-password" element={<ForgotPassword />} />
        </Routes>
      </div>
          
          <About />

    </BrowserRouter>
  );
}
