// src/pages/Dashboard.jsx
export default function Dashboard({ user }) {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <p>Welcome, {user?.name || "user"}!</p>
    </div>
  );
}
