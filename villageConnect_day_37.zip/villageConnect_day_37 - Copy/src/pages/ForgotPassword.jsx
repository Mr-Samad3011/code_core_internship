import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function ForgotPassword() {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState("");
  const [dob, setDob] = useState("");
  const [userId, setUserId] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const navigate = useNavigate();

  const handleVerify = async (e) => {
    e.preventDefault();
    const res = await fetch("http://localhost:5000/api/auth/verify-user", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, dob }),
    });

    const data = await res.json();
    if (res.ok) {
      setUserId(data.userId);
      setStep(2);
    } else {
      alert(data.error);
    }
  };

  const handleReset = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      return alert("Passwords do not match");
    }

    const res = await fetch("http://localhost:5000/api/auth/reset-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, newPassword }),
    });

    const data = await res.json();
    if (res.ok) {
      alert("Password reset successfully!");
      navigate("/login");
    } else {
      alert(data.error);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-6 border shadow rounded">
      {step === 1 ? (
        <form onSubmit={handleVerify}>
          <h2 className="text-xl font-bold mb-4 text-blue-500">Verify Email and DOB</h2>
          <input
            type="email"
            placeholder="Email"
            className="block w-full mb-3 p-2 border"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="date"
            className="block w-full mb-3 p-2 border"
            value={dob}
            onChange={(e) => setDob(e.target.value)}
            required
          />
          <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
            Next
          </button>
        </form>
      ) : (
        <form onSubmit={handleReset}>
          <h2 className="text-xl font-bold mb-4 text-blue-500">Set New Password</h2>
          <input
            type="password"
            placeholder="New Password"
            className="block w-full mb-3 p-2 border"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Confirm Password"
            className="block w-full mb-3 p-2 border"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
          <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded">
            Reset Password
          </button>
        </form>
      )}
    </div>
  );
}
