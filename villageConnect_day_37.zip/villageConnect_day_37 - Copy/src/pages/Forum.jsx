import { useState, useEffect } from "react";
import axios from "axios";

export default function Forum() {
  const [posts, setPosts] = useState([]);
  const [form, setForm] = useState({ title: "", content: "", author: "" });

  useEffect(() => {
    axios.get("http://localhost:5000/api/posts") 
      .then(res => setPosts(res.data))
      .catch(err => console.error(err));
  }, []);

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const res = await axios.post("http://localhost:5000/api/posts", form);
    setPosts([res.data, ...posts]);
    setForm({ title: "", content: "", author: "" });
  };
console.log("Form Submitted", form);

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4 text-blue-500">Community Forum</h1>
      <form onSubmit={handleSubmit} className="space-y-2 mb-6">
        <input required name="title" value={form.title} onChange={handleChange} placeholder="Title" className="w-full p-2 border" />
        <textarea required name="content" value={form.content} onChange={handleChange} placeholder="Content" className="w-full p-2 border" />
        <input required name="author" value={form.author} onChange={handleChange} placeholder="Your Name" className="w-full p-2 border" />
        <button className="bg-blue-500 text-white px-4 py-2" type="submit">Post</button>
      </form>
      {posts.map((p, i) => (
        <div key={i} className="border p-4 my-2">
          <h2 className="text-xl font-semibold text-gray-600">{p.title}</h2>
          <p className="text-gray-600">{p.content}</p>
          <p className="text-sm text-gray-500 text-gray-600">— {p.author}</p>
        </div>
      ))}
    </div>
  );
}
