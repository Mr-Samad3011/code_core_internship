// vite.config.js
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {

      external: ['lucide-react']  // optional step

      // external removed to fix lucide-react module resolution error
//65184ee (fix: resolve merge conflict in server.js and unify CORS configuration)
    }
  }
});
