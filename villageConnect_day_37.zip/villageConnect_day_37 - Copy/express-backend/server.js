const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const app = express();

//  CORS Configuration
const allowedOrigins = [
  "http://localhost:5173",
  "http://localhost:5174",
   
];

app.use(
  cors({
    origin: function (origin, callback) {
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error("Not allowed by CORS"));
      }
    },
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type"],
    credentials: true,
  })
);

//  Middleware
app.use(express.json());

//  Routes
const authRoutes = require("./routes/auth");
const serviceRoutes = require("./routes/serviceRoutes");
const postRoutes = require("./routes/forumRoutes");

app.use("/api/auth", authRoutes);
app.use("/api/services", serviceRoutes);
app.use("/api/posts", postRoutes);

//  MongoDB Connection
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log(" MongoDB connected"))
  .catch((err) => console.error(" MongoDB error:", err));

//  Seed Data (Optional)
const Service = require("./models/service");

app.get("/api/seed", async (req, res) => {
  const data = [
    {
      name: "Soil Testing",
      category: "Agriculture",
      description: "Helps farmers improve crop yield by testing soil quality.",
    },
    {
      name: "Telemedicine",
      category: "Health",
      description: "Remote access to doctors for villagers.",
    },
  ];

  try {
    await Service.insertMany(data);
    res.send(" Sample services inserted.");
  } catch (err) {
    console.error("Error inserting seed data:", err);
    res.status(500).send("Failed to insert services.");
  }
});

//  Clear All Services (Optional)
app.get("/api/clear", async (req, res) => {
  try {
    await Service.deleteMany({});
    res.send(" All services deleted.");
  } catch (err) {
    res.status(500).send("Failed to clear services.");
  }
});

//  Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(` Server running at http://localhost:${PORT}`);
});
