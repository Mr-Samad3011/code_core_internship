const express = require("express");
const router = express.Router();
const Service = require("../models/service");

// GET all services
router.get("/", async (req, res) => {
  try {
    const services = await Service.find();
    res.json(services);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch services" });
  }
});

// POST a new service
router.post("/", async (req, res) => {
  const { category, name, contact, address, description, information, availability, servicename, createdBy } = req.body;
  try {
    const newService = new Service({ category, name, contact, address, description, information, availability, servicename, createdBy });
    await newService.save();
    res.status(201).json(newService);
  } catch (err) {
    res.status(400).json({ error: "Failed to add service" });
  }
});



module.exports = router;
