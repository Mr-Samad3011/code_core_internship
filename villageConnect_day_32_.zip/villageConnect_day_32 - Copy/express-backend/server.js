const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const Service = require("./models/service");

const app = express();
app.use(cors());
app.use(express.json());

//  Connect to MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log(" MongoDB connected to villageconnect"))
  .catch((err) => console.error(" MongoDB error:", err));

//  GET route: fetch all services
app.get("/api/services", async (req, res) => {
  try {
    const services = await Service.find();
    res.json(services);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch services" });
  }
});


//  GET route: seed sample services
app.get("/api/seed", async (req, res) => {
  const data = [
    {
      name: "Soil Testing",
      category: "Agriculture",
      description: "Helps farmers improve crop yield by testing soil quality."
    },
    {
      name: "Telemedicine",
      category: "Health",
      description: "Remote access to doctors for villagers."
    }
  ];

  try {
    await Service.insertMany(data);
    res.send(" Sample services inserted into villageconnect DB.");
  } catch (err) {
    console.error(" Error inserting seed data:", err);
    res.status(500).send(" Failed to insert services.");
  }
});

app.post("/api/services", async (req, res) => {
  try {
    const { name, category, description } = req.body;
    const newService = new Service({ name, category, description });
    await newService.save();
    res.status(201).json(newService);
  } catch (err) {
    res.status(400).json({ error: "Failed to create service" });
  }
});

app.get("/api/clear", async (req, res) => {
  await Service.deleteMany({});
  res.send("🧹 All services deleted");
});

//  Start the server
app.listen(5000, () => {
  console.log(" Server running at http://localhost:5000");
});
