const services = [
  {
    name: "Soil Testing",
    category: "Agriculture",
    description: "Farmers can test their soil for better productivity.",
  },
  {
    name: "Telemedicine",
    category: "Health",
    description: "Connect with certified doctors from rural areas.",
  },
  {
    name: "Irrigation Planning",
    category: "Agriculture",
    description: "Smart water usage for higher efficiency in farming.",
  },
];

export default services;
