export default function ServiceCard({ service }) {
  return (
    <div className="bg-white shadow-md p-4 rounded">
      <h2 className="text-lg font-semibold text-gray-800">{service.name}</h2>
      <p className="text-sm text-gray-600">Category: {service.category}</p>
      <p className="text-sm mt-2 text-gray-700">{service.description}</p>
    </div>
  );
}
