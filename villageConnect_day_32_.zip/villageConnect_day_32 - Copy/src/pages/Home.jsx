import ServiceCard from "../components/ServiceCard";

const sampleServices = [
  {
    name: "Soil Testing",
    category: "Agriculture",
    description: "Farmers can get their soil tested for better productivity."
  },
  {
    name: "Telemedicine",
    category: "Health",
    description: "Connect with certified doctors from rural areas."
  },
    {
    name: "Soil Testing",
    category: "Agriculture",
    description: "Farmers can get their soil tested for better productivity."
  },
  {
    name: "Telemedicine",
    category: "Health",
    description: "Connect with certified doctors from rural areas."
  }
];

export default function Home() {
  return (
<div className="min-h-screen w-screen bg-gray-100 flex flex-col px-4 py-6">
  <h1 className="text-2xl font-bold text-center mb-6 text-blue-500">
    VillageConnect Services
  </h1>

  <div className="flex-grow grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-6xl mx-auto">
    {sampleServices.map((service, i) => (
      <ServiceCard key={i} service={service} />
    ))}
  </div>
</div>






  );
}
