const express = require('express');
const mongoose = require('mongoose');
const app = express();

app.use(express.json());

mongoose.connect('mongodb+srv://abdussamad7562:DeEqkDob5KYLpe7t@cluster0.nl6kxfx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log('MongoDB Connected');
}).catch((err) => {
  console.error('Connection error:', err);
});

const serviceSchema = new mongoose.Schema({
  name: String,
  description: String,
});

const Service = mongoose.model('Service', serviceSchema);

// Create Service
app.post('/services', async (req, res) => {
  try {
    const service = new Service(req.body);
    await service.save();
    res.status(201).send(service);
  } catch (err) {
    res.status(400).send(err);
  }
});

// Get All Services
app.get('/services', async (req, res) => {
  const services = await Service.find();
  res.send(services);
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
