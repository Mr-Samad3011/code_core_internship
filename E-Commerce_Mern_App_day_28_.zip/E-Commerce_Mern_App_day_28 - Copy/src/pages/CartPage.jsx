export default function CartPage({ cartItems }) {
  const total = cartItems.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="min-h-screen w-screen bg-gray-100 p-6">
      <h1 className="text-2xl font-bold mb-6 text-center">🛒 Your Cart</h1>

      {cartItems.length === 0 ? (
        <p className="text-center text-gray-500">Your cart is empty.</p>
      ) : (
        <div className="max-w-2xl mx-auto bg-white p-4 rounded shadow">
          {cartItems.map((item, index) => (
            <div key={index} className="border-b py-2">
              <p className="font-semibold">{item.name}</p>
              <p className="text-sm text-gray-600">₹{item.price}</p>
            </div>
          ))}
          <div className="font-bold text-right mt-4">Total: ₹{total}</div>
        </div>
      )}
    </div>
  );
}
