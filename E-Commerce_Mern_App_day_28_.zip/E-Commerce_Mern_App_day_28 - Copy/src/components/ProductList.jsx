import { useEffect, useState } from "react";
import axios from "axios";
import ProductCard from "../components/ProductCard";

export default function ProductList({ onAddToCart }) {
  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState("");

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/products", {
        params: { category },
      })
      .then((res) => setProducts(res.data));
  }, [category]);

  return (
    <div className="min-h-screen w-screen bg-gray-100 flex flex-col items-center px-4 py-6">
      <h1 className="text-2xl font-bold mb-6 text-center">Product List</h1>

      <div className="mb-4 w-full max-w-xs">
        <select
          onChange={(e) => setCategory(e.target.value)}
          className="p-2 border rounded w-full"
        >
          <option value="">All Categories</option>
          <option value="headphones">Headphones</option>
          <option value="broadband">Broadband</option>
        </select>
      </div>

      <div className="w-full max-w-7xl grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((p) => (
          <ProductCard key={p._id} product={p} onAddToCart={onAddToCart} />
        ))}
      </div>
    </div>
  );
}
