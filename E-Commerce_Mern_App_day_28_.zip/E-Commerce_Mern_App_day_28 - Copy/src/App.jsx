import { useState } from "react";
import { Routes, Route, Link } from "react-router-dom";
import ProductList from "./pages/ProductList";
import CartPage from "./pages/CartPage";

export default function App() {
  const [cartItems, setCartItems] = useState([]);

  const handleAddToCart = (product) => {
    setCartItems([...cartItems, product]);
  };

  return (
    <div>
      {/* Simple Navbar */}
      <div className="bg-white shadow p-4 flex justify-between px-6">
        <Link to="/" className="font-bold text-blue-600">🛍️ Shop</Link>
        <Link to="/cart" className="text-gray-700">Cart ({cartItems.length})</Link>
      </div>

      <Routes>
        <Route path="/" element={<ProductList onAddToCart={handleAddToCart} />} />
        <Route path="/cart" element={<CartPage cartItems={cartItems} />} />
      </Routes>
    </div>
  );
}
