const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

mongoose
  .connect("mongodb+srv://abdussamad7562:DeEqkDob5KYLpe7t@cluster0.nl6kxfx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("MongoDB Connected"));

const productSchema = new mongoose.Schema({
  name: String,
  price: Number,
  image: String,
  category: String,
});

const Product = mongoose.model("Product", productSchema);

// GET with optional category filter
app.get("/api/products", async (req, res) => {
  const { category } = req.query;
  const query = category ? { category } : {};
  const products = await Product.find(query);
  res.json(products);
});

//  POST sample seed data (optional)
app.post("/api/seed-products", async (req, res) => {
  await Product.insertMany([
    {
      name: "Wireless Headphones",
      price: 2499,
      image: "https://m.media-amazon.com/images/I/517lSvEVVsL._SX679_.jpg",
      category: "headphones",
    },
    {
      name: "Broadband Router",
      price: 1200,
      image: "https://m.media-amazon.com/images/I/512sO2L0k6L._SX679_.jpg",
      category: "broadband",
    },
  ]);
  res.json({ message: "Products inserted" });
});

app.listen(5000, () => console.log(" Server on http://localhost:5000"));
