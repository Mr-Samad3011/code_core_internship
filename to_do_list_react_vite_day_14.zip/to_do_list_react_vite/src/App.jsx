
import './App.css'
import To_do_List from './To_do_List'
function App() {
  // const [count, setCount] = useState(0)

  return (
    <>
      <To_do_List />
    </>
  )
}

export default App
