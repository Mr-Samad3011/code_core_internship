import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Signup() {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSignup = async () => {
    try {
      await axios.post("http://localhost:5000/api/signup", form);
      alert("Signup successful");
      navigate("/login");
    } catch (err) {
      alert(err.response?.data?.error || "Signup failed");
    }
  };

  return (
   <div className="h-screen w-screen flex items-center justify-center bg-gray-800">
  <div className="max-w-sm w-full p-6 bg-white rounded shadow">
    <h2 className="text-xl font-bold mb-4 text-center text-orange-700">Signup</h2>
    <input name="name" onChange={handleChange} placeholder="Name" className="w-full p-2 mb-2 border rounded" />
    <input name="email" onChange={handleChange} placeholder="Email" className="w-full p-2 mb-2 border rounded" />
    <input type="password" name="password" onChange={handleChange} placeholder="Password" className="w-full p-2 mb-4 border rounded" />
    <button onClick={handleSignup} className="bg-green-600 text-white w-full py-2 rounded hover:bg-green-700">Signup</button>
  </div>
</div>

  );
}
