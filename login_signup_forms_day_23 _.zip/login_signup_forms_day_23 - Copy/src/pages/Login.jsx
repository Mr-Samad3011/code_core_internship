import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [form, setForm] = useState({ email: "", password: "" });
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleLogin = async () => {
    try {
      const res = await axios.post("http://localhost:5000/api/login", form);
      localStorage.setItem("token", res.data.token);
      alert("Login successful");
      navigate("/");
    } catch (err) {
      alert(err.response?.data?.error || "Login failed");
    }
  };

  return (
   <div className="h-screen w-screen flex items-center justify-center bg-gray-700">
  <div className="max-w-sm w-full p-6 bg-white rounded shadow">
    <h2 className="text-xl font-bold mb-4 text-center text-orange-700">Login</h2>
    <input
      name="email"
      onChange={handleChange}
      placeholder="Email"
      className="w-full p-2 mb-2 border rounded"
    />
    <input
      type="password"
      name="password"
      onChange={handleChange}
      placeholder="Password"
      className="w-full p-2 mb-4 border rounded"
    />
    <button
      onClick={handleLogin}
      className="bg-blue-600 text-white w-full py-2 rounded hover:bg-blue-700"
    >
      Login
    </button>
  </div>
</div>

  );
}
