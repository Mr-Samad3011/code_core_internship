import { useState } from 'react';
import './App.css'

function App() {
   let [counter, setCounter] = useState(0)

    const addvalue=() =>{
      
      if(counter === 20){
        counter=counter-1;
      }
      else{
      counter=counter+1
      console.log("clicked",counter);
      setCounter(counter)
      }
    }

    const decreseValue=()=>{
      
        if(counter=== 0){
          counter = counter+1;
        }
        else{
  counter=counter-1;
      console.log("clicked",counter)
        setCounter(counter)
        }
        
    }

    const reset= ()=>{
      counter=0;
      setCounter(counter)
    }

  return (
    <>
    <h1>Simple Counter Created By Abdus Samad</h1>
    <h2>Counter Value <span id='countervalue' >{counter}</span></h2>
    
    <div className="btn">
      <button onClick={addvalue}>Increment </button>
       <button onClick={reset}>Reset</button>
    <button onClick={decreseValue}>Decrement</button>
   
    </div>
    </>
  )
}

export default App
