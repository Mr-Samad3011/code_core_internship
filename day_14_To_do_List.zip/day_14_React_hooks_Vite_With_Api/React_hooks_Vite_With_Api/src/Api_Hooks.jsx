import Navbar from './Navbar'; 
import { useEffect, useMemo, useRef, useState } from 'react';

const LS_KEY = 'todo.tasks.v1';

function loadTasks() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveTasks(tasks) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(tasks));
  } catch {}
}

function makeId() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return String(Date.now()) + Math.random().toString(16).slice(2);
}

export default function Api_Hooks() {
  const [tasks, setTasks] = useState(() => loadTasks()); // [{id,text,done,createdAt}]
  const [input, setInput] = useState('');
  const [filter, setFilter] = useState('all'); // all | active | completed
  const [editingId, setEditingId] = useState(null);
  const [editingText, setEditingText] = useState('');
  const inputRef = useRef(null);

  // Persist to localStorage on change
  useEffect(() => {
    saveTasks(tasks);
  }, [tasks]);

  const visibleTasks = useMemo(() => {
    if (filter === 'active') return tasks.filter(t => !t.done);
    if (filter === 'completed') return tasks.filter(t => t.done);
    return tasks;
  }, [tasks, filter]);

  function addTask() {
    const text = input.trim();
    if (!text) return;
    setTasks(prev => [{ id: makeId(), text, done: false, createdAt: Date.now() }, ...prev]);
    setInput('');
    inputRef.current?.focus();
  }

  function deleteTask(id) {
    setTasks(prev => prev.filter(t => t.id !== id));
  }

  function toggleDone(id) {
    setTasks(prev => prev.map(t => (t.id === id ? { ...t, done: !t.done } : t)));
  }

  function startEdit(id, currentText) {
    setEditingId(id);
    setEditingText(currentText);
  }

  function saveEdit() {
    const txt = editingText.trim();
    if (!txt) return;
    setTasks(prev => prev.map(t => (t.id === editingId ? { ...t, text: txt } : t)));
    setEditingId(null);
    setEditingText('');
  }

  function cancelEdit() {
    setEditingId(null);
    setEditingText('');
  }

  function clearCompleted() {
    setTasks(prev => prev.filter(t => !t.done));
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-slate-50 to-slate-100">
      <Navbar />

      <main className="flex-1 flex flex-col items-center justify-start p-4">
        <div className="w-full max-w-xl bg-white p-6 sm:p-7 rounded-2xl shadow-lg border border-slate-200">
          {/* Add */}
          <div className="flex gap-2 mb-4">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && addTask()}
              placeholder="Enter a task..."
              className="flex-1 border border-slate-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 "
            />
            <button
              onClick={addTask}
              className="bg-blue-600 text-white px-4 py-2 rounded-md font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              Add
            </button>
          </div>

          {/* Filters + Clear */}
          <div className="flex flex-wrap items-center gap-2 mb-3 text-blue-600">
            <FilterBtn active={filter === 'all'} onClick={() => setFilter('all')}>All</FilterBtn>
            <FilterBtn active={filter === 'active'} onClick={() => setFilter('active')}>Active</FilterBtn>
            <FilterBtn active={filter === 'completed'} onClick={() => setFilter('completed')}>Completed</FilterBtn>
            <div className="ml-auto">
              <button
                onClick={clearCompleted}
                className="text-sm px-3 py-1.5 rounded-md border border-slate-300 hover:bg-slate-50"
              >
                Clear completed
              </button>
            </div>
          </div>

          {/* List */}
          <ul className="space-y-2">
            {visibleTasks.length === 0 ? (
              <li className="text-slate-500 text-center py-8">
                No tasks here — add something above 
              </li>
            ) : (
              visibleTasks.map((t) => (
                <li
                  key={t.id}
                  className="flex items-center gap-3 bg-slate-50 px-4 py-2 rounded border border-slate-200"
                >
                  {/* Checkbox */}
                  <input
                    type="checkbox"
                    checked={t.done}
                    onChange={() => toggleDone(t.id)}
                    className="h-5 w-5 rounded border-slate-300 focus:ring-blue-500"
                  />

                  {/* Text / Edit */}
                  <div className="flex-1">
                    {editingId === t.id ? (
                      <input
                        autoFocus
                        value={editingText}
                        onChange={(e) => setEditingText(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') saveEdit();
                          if (e.key === 'Escape') cancelEdit();
                        }}
                        className="w-full  rounded-md border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    ) : (
                      <span className={t.done ? 'line-through text-slate-400' : 'text-slate-800'}>
                        {t.text}
                      </span>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    {editingId === t.id ? (
                      <>
                        <button
                          onClick={saveEdit}
                          className="px-3 py-1.5 rounded-md bg-green-600 text-white text-sm hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500"
                        >
                          Save
                        </button>
                        <button
                          onClick={cancelEdit}
                          className="px-3 py-1.5 rounded-md text-blue-600 border border-slate-300 text-sm hover:bg-slate-50"
                        >
                          Cancel
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={() => startEdit(t.id, t.text)}
                          className="px-3 py-1.5 rounded-md border text-blue-600 border-slate-300 text-sm hover:bg-slate-50 "
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => deleteTask(t.id)}
                          className="px-3 py-1.5 rounded-md bg-red-600 text-white text-sm hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500"
                        >
                          Delete
                        </button>
                      </>
                    )}
                  </div>
                </li>
              ))
            )}
          </ul>

          {/* Stats */}
          <div className="mt-3 text-sm text-slate-600">
            Total: {tasks.length} · Completed: {tasks.filter(t => t.done).length}
          </div>
        </div>
      </main>
    </div>
  );
}

function FilterBtn({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className={`text-sm px-3 py-1.5 rounded-md border ${
        active ? 'border-blue-600 text-blue-700 bg-blue-50' : 'border-slate-300 hover:bg-slate-50'
      }`}
    >
      {children}
    </button>
  );
}
