import { useState, useEffect } from 'react';
import axios from 'axios';
import SearchBar from './components/SearchBar';

function App() {
  
  const [services, setServices] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    axios.get('http://localhost:3000/services')
      .then(res => setServices(res.data))
      .catch(err => console.log(err));
  }, []);

  const filteredServices = services.filter(service =>
  (service?.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
   service?.description?.toLowerCase().includes(searchQuery.toLowerCase()))

);




  return (
    <div className="w-screen min-h-screen bg-gray-100 p-6">
      <h1 className="text-3xl font-bold mb-4 text-center">Services Dashboard</h1>

      {/*  SearchBar Component */}
      <SearchBar searchQuery={searchQuery} setSearchQuery={setSearchQuery} />

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {filteredServices.length > 0 ? (
          filteredServices.map((service) => (
            <div key={service._id} className="bg-white p-4 rounded-xl shadow hover:shadow-lg transition">
              <h2 className="text-xl font-semibold text-blue-600">{service.name}</h2>
              <p className="text-gray-700">{service.description}</p>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-500 col-span-full">No services found.</p>
        )}
      </div>
    </div>
  );
}

export default App;
